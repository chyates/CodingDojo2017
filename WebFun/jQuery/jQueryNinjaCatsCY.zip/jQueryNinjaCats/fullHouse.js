$(document).ready(function () {
    //     $("img").click(function () {
    //         alert("The image was clicked.");
    // });
    $("#DT0").click(function () {
        $(this).attr("src", "davecoulier0.jpg");
    })
    $("#DT1").click(function () {
        $(this).attr("src", "davecoulier1.jpg");
    })
    $("#DT2").click(function () {
        $(this).attr("src", "davecoulier2.jpg");
    })
    $("#DT3").click(function () {
        $(this).attr("src", "davecoulier3.jpg");
    })
    $("#DT4").click(function () {
        $(this).attr("src", "davecoulier4.jpg");
    })
    $("#b-FH").click(function () {
        $("#DT0").attr("src", "dannytanner0.jpg");
        $("#DT1").attr("src", "dannytanner1.jpg");
        $("#DT2").attr("src", "dannytanner2.jpg");
        $("#DT3").attr("src", "dannytanner3.jpg");
        $("#DT4").attr("src", "dannytanner4.jpg");
    })
})