$(document).ready(function () {
    //attach a click event listener to all the img tags when the document is ready
    $('.pics').click(function () {
        $(this).hide();
    });
});