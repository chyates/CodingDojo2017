using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace userDash2.Models
{
  public abstract class BaseEntity {}
}